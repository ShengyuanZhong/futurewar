"""Eight-way, unit-cost paths; a blocked corner does not prohibit a diagonal."""
from collections import deque
from .protocol import Pos, Turn, Unit


class Routes:
    def __init__(self, turn: Turn, role: Unit, reserved: set[Pos] | None = None):
        self.start = role.pos
        blocked = turn.blocked(role) | frozenset(reserved or ())
        self.cost = {role.pos: 0}
        self.first: dict[Pos, Pos] = {}
        frontier = deque([role.pos])
        while frontier:
            here = frontier.popleft()
            for there in here.neighbours():
                if not turn.land(there) or there in blocked or there in self.cost:
                    continue
                self.cost[there] = self.cost[here] + 1
                self.first[there] = there if here == role.pos else self.first[here]
                frontier.append(there)

    def nearest(self, goals) -> Pos | None:
        reachable = [p for p in goals if p in self.cost]
        return min(reachable, key=lambda p: (self.cost[p], p)) if reachable else None

    def step(self, goals) -> Pos | None:
        return self.first.get(self.nearest(goals))


def adjacent_cells(turn: Turn, targets) -> set[Pos]:
    targets = set(targets)
    return {p for t in targets for p in t.neighbours() if p not in targets and turn.land(p)}


def next_step(turn: Turn, moving: Unit, goal: Pos) -> Pos | None:
    return Routes(turn, moving).step([goal])
