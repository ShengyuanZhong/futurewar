# 开发与维护文档

更新日期：2026-09-23，版本0.3.10。本轮接入用户新版任务控制器与提示词，见[任务接入](TASK_INTEGRATION.md)。战斗、升级、维修和工人策略沿用0.3.9；接取任务增加点位快照与冷却检查。

## 1. 设计目标与边界

程序是参赛选手 Agent：输入判题器提供的观测，输出动作、LLM prompt 和官方沙盒命令。它不承担判题器职责，不自行模拟对方隐藏状态、不结算复活/金币收入/伤害/得分，也不会在本机执行 `executeCmd`。

保留 demo 的协议、地图、策略三个主要模块，把 HTTP 与跨回合状态放在用户建议的 `CoreGeek/app` 内。仅使用 Python 标准库，避免部署时下载依赖。

## 2. 目录和职责

```text
CoreGeek/
├── main3.py                      # 参数、日志、启动入口
├── run.sh                        # 官方 bash run.sh port 入口
├── pyproject.toml                # Python 版本与可选打包
├── config.example.json          # 无已核验坐标的示例配置
├── app/
│   ├── config.py                 # 配置校验，按阵营计算建造坐标
│   ├── server.py                 # HTTP 读取/响应/错误分类
│   └── service/
│       ├── turn_service.py       # 一次回合事务、缓存、状态隔离
│       ├── memory.py             # 新闻、任务、额度与行为反馈记忆
│       ├── llm_service.py        # prompt、结构化回复解析与校验
│       ├── task_prompt.py       # 项目维护的任务prompt
│       ├── task_controller.py   # 用户控制器：SOP/Skill、任务推进与失败退出
│       ├── task_state.py        # 同局任务状态和经验库
│       ├── task_context.py      # 协议适配、证据、诊断与预算
│       └── task_service.py       # 活跃任务、沙盒与答案协作
├── src/agent/
│   ├── protocol.py               # 官方 DTO、常量、坐标与结果解析
│   ├── grid.py                   # 八方向 BFS 与相邻交互格
│   ├── actions.py                # 十二动作统一入口与预算
│   ├── construction.py           # 当前建造区域内规划三炮及共同操控格
│   ├── upgrade_policy.py         # 单炮集中升级、分组墙目标与完成判断
│   ├── worker_coordinator.py     # 独立任务、目的格和协作侧移
│   ├── wall_guard.py             # 阈值维修、双人值守与轮流采购
│   ├── combat.py                 # 目标与弹道估值、旧匹配接口
│   ├── brain.py                  # 白天/夜间策略编排
│   └── server.py                 # 旧 server 导入兼容
├── tests/                        # 独立可手算案例、服务/HTTP测试
├── tools/                        # 离线回放、实进程冒烟、验证报告
└── docs/                         # 当前文档及协议/规则覆盖文档
```

依赖方向：HTTP → TurnService → protocol / TaskService / LLMService / Strategy → ActionPlan / Routes / combat。`agent` 主体只通过配置和记忆对象消费策略参数；旧 `decide` 包装器为兼容才延迟导入应用默认值。

```mermaid
flowchart LR
  J[判题器观测] --> H[app.server]
  H --> S[TurnService]
  S --> M[复制记忆并处理反馈]
  M --> L[任务与新闻服务]
  L --> B[Strategy]
  B --> A[ActionPlan 校验与预留]
  A --> R[roleCommandMap / prompt / executeCmd]
  R --> C[提交记忆和响应缓存]
  C --> H
  H --> J
```

## 3. 一次回合的处理

1. HTTP 校验长度、UTF-8 和 JSON，最多 2 MiB，可配置；正式模式仅接受 41×32、回合 1–1300。
2. 按 `(teamId, type)` 找会话。同回合相同请求返回深拷贝缓存；同回合不同内容、旧回合拒绝。已有较大回合后收到第 1 回合时开启新会话。
3. 深拷贝记忆，按游戏日重置普通 LLM 额度和召唤令尝试数；记录新闻及官方动作反馈。
4. 只消费紧接上次发送轮次的 LLM 回复；任务回复还必须匹配当前任务原文。旧回复不得进入新任务。
5. 创建ActionPlan与Strategy，选择/复用布局，计算`defense_due`。活跃任务没有防守冲突时保持站位并处理答案/沙盒；需要回防时不占用开拓者，不输出任务prompt或命令。
6. 先安排开拓者，再按停滞情况、维修身份和ID分别控制工人；白天开局建设/经济，普通工人昼夜统一升级/采购/采矿，夜间需避敌且不能建造，维修工墙内值守并可内侧升级；全部目标完成后两人全天墙内维修，白天轮流买包；持有Medicine的低血量角色优先用药。开局未完成时暂停普通券采购和宝藏采购。
7. 所有策略动作通过 `ActionPlan.add`。成功后预留操作者、目的格和金币；失败记录原因，不写入响应。
8. 普通新闻 prompt 只在任务外生成，每日最多三次；活跃任务 prompt 不计入普通额度。
9. 决策完成才提交记忆与响应。异常时不提交半成品状态；HTTP 返回空动作，完整记录异常。

进程使用短时间锁串行保护状态；无法在 100ms 内取得锁时返回空动作并记录 `decision_busy`，避免请求在锁上排队超时。最多保留 16 个队伍/阵营会话。官方每队独立进程顺序请求是主运行方式。

协议未提供 matchId。无法区分“上局只有第1轮且新局第1轮输入完全相同”和“原第1轮重试”；此情形按重试处理。正式比赛按要求每场重新启动进程，因此不依赖这种推断。中途重启无法恢复过去新闻，当前无磁盘记忆恢复功能。

## 4. 配置与建造区域

| 配置 | 默认值 | 含义 |
|---|---|---|
| `layouts` | `{}` | challenger/defender 分别登记建造区域 |
| `allow_base_surroundings` | true | 无已确认阵营布局时，按用户假设生成基地周围建造格 |
| `loadout` | rocket、rocket、rocket | 三座武器的目标组合；显式旧配置仍覆盖默认值 |
| `sell_batch` | 12 | 不在小贩旁时开始运矿销售的携带数量 |
| `return_margin` | 4 | 回防预留轮数，也是宝藏准备时间余量 |
| `enable_tasks` | true | 是否主动接新任务，已存在任务仍会处理 |
| `enable_news` | true | 是否启用普通新闻 LLM 分析 |
| `max_body_bytes` | 2097152 | HTTP 请求大小上限 |

每个 `layouts` 项固定包含 `verified`、`source`、`weapons`、`walls`。两个位置数组用相对基地**左上角**偏移：实际坐标为 `(base.x + offset.x, base.y + offset.y)`，y 正方向向上；基地本身占 `(x,y),(x+1,y),(x,y-1),(x+1,y-1)`。

例如数学上基地 `(10,24)` 加偏移 `(-1,0)` 等于 `(9,24)`；这只解释坐标算法，不证明该格属于官方蓝区。不得从示例测试推断地图区域。阵营偏移分别登记，不自动假设镜像。武器与墙列表不能重叠或重复；越界、基地内、中立格在使用时过滤。

默认已启用建造，不需要config.local.json。`base_surrounding_offsets(kind, mirrored=False)`按2×2基地生成3格后排竖排火箭与12格U形墙，墙内留一格维修通路。`mirrored_layout(turn)`按基地中心决定左右，右侧偏移为`(1-dx,dy)`；`default_operator_position(turn)`固定P在中间火箭后侧。平移后过滤越界、基地和非空地中立点。完整参数和示意图见[U形布局](U_LAYOUT.md)。构造依据是用户明确允许的基地周围假设，不标记成官方确认坐标。

如果提供`verified:true`且有source的自定义布局，它优先于默认布局。若要恢复仅允许确认区域的模式，显式设置`allow_base_surroundings:false`。已有模板中verified:false的空布局会使用默认区域，不再阻止开局建炮。

## 5. 策略修改位置

### 采集与经济

`brain.py:Strategy.opening_worker`负责白天开局，顺序为三炮建造→按缺墙数攒足石头→建墙。完成状态必须从后续观测确认，不把已发出的build当作成功。初始75金币优先建三火箭，两个工人每轮最多建两座；没有足够金币时才先恢复采卖筹资。`stone_targets`按存活工人库存及容量分配石头，墙数超过合计容量时分批。

`run_worker`负责工人昼夜统一入口；`night_worker`保留为兼容转发。普通工人沿用相同经济优先级，夜间也可采购/配送/用券；缺墙保留石材，采矿按实时矿价与安全路线选择，满背包或达到运矿阈值时卖矿。夜间不建造，不分配工人控炮。职责约束和函数参数见[昼夜统一调度](WORKER_SCHEDULE.md)。

开局完成后的白天优先`rebuild_wall`补墙/筹石，在商店旁可补齐当前火箭两种券，再用券、补炮、卖矿、买券、挖矿。销售按实时`vendorShopList`和行走成本选择矿种，并保护缺墙材料；购买读取当前`weaponShopList`并预留缺炮预算。购券和用券共享`upgrade_candidates`阶段，第一天只集中升首炮；第二天起按首炮3→中央墙3→第二炮2→外围墙2→外围墙3→所有炮3→两翼墙2推进，基地不升级。墙组内由前到后，全部目标完成后双工人全天维修、轮流采购。参数与案例见[维护策略](MAINTENANCE.md)。

销售收入不加入同回合可花金币，购买的物品也不当作同回合已经到手；下一轮以观测为准。两个工人同时采同一矿允许，因为官方有余量不足时各得一个的规则。失败采集对该坐标暂避三轮，不能据此断言整类矿永久停产。

新策略只需产生命令并交给 `plan.add`。不要直接改 `plan.commands`，也不要直接修改观测中的金币、HP 或背包。

### 移动与建造

`grid.Routes`在无风险时使用八方向BFS；工人遇机器人时传入风险图，按累计风险、实际步数Dijkstra。cost仍保存步数，exposure保存累计风险，first保存第一步；allowed约束墙内巡护；ignore_workers仅供堵路诊断，正式动作不允许进入当前占用格。斜角两侧有障碍仍能通过。

己方和可见敌方活单位、两格任务点、四格基地、中立点、矿点及机器人均进入障碍集合。为避免己方互换与争抢，当前占用格本轮不放行，已预留目标格也不放行。这比官方允许的部分跟随移动更保守，会降低拥挤场景效率；不会假装顺序移动就是同时结算。隐藏敌人和机器人未来位置仍可能造成合法动作执行失败。工人新增独立任务和目标预留，卡位时先让同伴侧移、下一轮确认位置后通过。

建造使用Settings返回的自定义区域或用户授权默认区域，所有炮型共享三座上限及金币预算。`construction.select_defense_layout`优先固定默认模板的三炮和P；自定义布局或既有炮不兼容模板时，仍在合法候选格内规划共同站位。布局保存在`GameMemory.defense_layout`。工人避免进入操控格，所有角色避免进入规划炮位；已经站在建筑预定格的角色尝试移开。真实路径、动态占用与最终建造仍在每轮检查。

策略不会主动覆盖已有炮；统一校验层支持合法覆盖。建墙前检查是否切断原本可达的小贩/己方任务点路线，以及开拓者通向操控格的路径。该检查不是完整的最优围墙设计器，区域配置仍应保留出入口。

### 防御

`Strategy.pioneer_should_defend`根据到操控格的当前路径成本与`return_margin`提前召回开拓者。`operate_weapons`仅让开拓者从相邻、冷却为0且有目标的武器中选择一座，优先预计有效伤害，同分按ID。没有共同站位时在炮位间移动；没有可攻击炮时就位等待。工人不参与操炮，即使开拓者死亡也保持采矿/夜修分工。第三天起单人夜修，全部目标达标后双人全天值守；WallGuard负责动态备货、采购轮换、上下区回岗和阈值修复；堵门时让行/等待，墙掩护按用户实战策略纳入风险图。

每轮一名角色只能操控一炮。按官方“发射后3轮空窗”，共享站位且每次都有目标时，三炮示例为A→B→C→空→A；实际选择由输入`cooldown`决定。`combat.pair_weapons`保留为兼容函数，当前Strategy不调用。

`choose_targets` 优先估值威胁己方基地的机器人：火箭搜索机器人及其邻域中的落点，考虑中心20/周围10和重叠；加特林校验任意目标方向点积不小于0；电磁炮按能量估值直线穿透。每次攻击目标数与等级相符。冷却以请求的 `cooldown` 为准，不私自推算减少冷却。

射程使用任务书表值，若输入报告较小有效射程则取较小者；输入较大值不扩展表值。这是 D02 冲突的保守处理，可能牺牲与某一判题版本的射程，需要官方版本确认。

弹道格子相交和同轮伤害分配仅用于选敌估值，最终伤害/机器人移动/击杀分完全由判题器结算。当前方格边界按闭区间、并列按ID排序，D07 未获官方确认。

### 任务与新闻

用户生成器在`task_prompt.py`，由`task_controller.SelfEvolveController`直接调用，SOP/Skill同时注入；状态存于`task_state.TaskAgentMemory`，通过GameMemory进入每队事务。`task_service.py`将Turn字段映射到用户控制器，再映射回ActionPlan/executeCmd；先处理旧任务结果再切换新题目，避免成功归档丢失。`llm_service.py`只登记和匹配task pending，将原始回复交给用户解析器；新闻流程仍独立。需要回防、死亡或失败退出时释放开拓者，同题目保持挂起直到官方状态变化；离开范围是否结束由官方反馈决定。TaskService的`defense_due=False`参数沿用。字段与阈值详见[任务接入文档](TASK_INTEGRATION.md)。

`skill` 内容最多保存最近8条，每条4000字符，是待验证的解题方法。没有通过率字段时，不擅自将其标记为成功经验。任务完成、超时、最高通过率奖励均由判题器决定。

宝藏仅在结构化高置信方案通过本地形状/商品校验后尝试；LLM的高置信度不等于官方确认。开局完成或未配置区域时才考虑宝藏，有炮回防优先于宝藏时间窗口。失败码2/3清理计划并记住目标/物品/窗口，避免重复相同消耗；1/4停止继续寻找。普通LLM额度按发送尝试保守计数，错误不会返还额度。

## 6. 加功能和修缺陷

1. 在变更说明中注明工程/策略/规则修复，以及 R 编号；不改任务书和接口原文迁就代码。
2. 规则修复先在 `tests` 添加可手算反例，确认能捕获问题，再修改 `protocol/actions/grid` 等共享模块。
3. 新角色策略通过 `Strategy` 调用 `ActionPlan`；新跨回合信息加到 `GameMemory`，确保拷贝提交、重复请求和换边测试覆盖。
4. 新 LLM 返回字段必须在 `LLMService`/`task_context.normalize_reply` 显式校验；不要执行任意返回的 Python，也不要把 LLM 给出的整份角色动作直接合入响应。
5. 修改后运行`python run_tests.py`。涉及入口/协议时再跑`tools/smoke_server.py --output ../reports/http-smoke-版本.json`；更新验证报告运行`tools/validate.py --cases 20 --output ../reports/validation-版本.json`，保留旧报告。
6. 在真实平台获得回放后，另存请求序列、平台版本与结算结果。输入可以直接交给 `tools/replay.py`，但离线回放不会模拟命令结果。

## 7. 日志与诊断

| 事件 | 含义 | 检查位置 |
|---|---|---|
| `construction_mode=base_surroundings` | 已启用基地周围默认布局 | allow_base_surroundings / 用户指定的本地假设 |
| `D01` | 显式关闭默认布局且没有确认坐标 | config |
| `decision` | 回合、阵营、动作数、耗时、反馈失败数、错误码、opening阶段、shared_control | 策略与原始观测；shared_control只代表规划具备共同邻格 |
| `action_rejected` | 本地动作校验拦截 | 对应策略与 ActionPlan |
| `protocol_error` | HTTP/JSON/必要字段/序列错误，返回400 | 请求和接入路径 |
| `decision_failed` | 内部缺陷，返回空动作且不提交状态 | traceback，补回归测试 |
| `decision_busy` | 并发锁繁忙，降级为空动作 | 是否存在非官方并发调用 |

不把本地HTTP错误、官方 `errors`、`lastRoundRoleActionResults=false` 混为同一个异常计数。日志不默认输出完整 prompt、新闻、答案和沙盒输出。决策循环及攻击候选搜索有3.5秒软预算，但不是硬实时保证；本机时延数据见验证报告。
